import "./Body.css";

const Body = () => {
const numA = 8;
const numB = 16;
const objA = {
    aaa : 1,
    bbb : 2,
}
    return ( 

    <div className="body">
        <h1>바디 태그입니다</h1>

        <p>{numA} 보이시죠? 숫자데이터 표시가 됩니다</p>
        <p>{numA + numB} 보이시죠? 계산도 됩니다</p>
        <p>{objA.aaa}</p>

        /* 자바스크립트 삼항 연산자입니다 */
        <p>{numB}는 {numB % 2 === 0 ? "짝수" : "홀수"}입니다</p>
        </div>
        )

}
export default Body;