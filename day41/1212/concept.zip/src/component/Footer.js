const Footer = () => {
    return ( 
    <footer>
        <h1>푸터 태그입니다</h1>
    </footer>
    )
}
export default Footer;