
USE `proto_1`;


INSERT INTO `shopproducts` VALUES (4,'윈터솔저',1600,'http://localhost:8000/윈터솔저.jpg',2,'2024-05-15 13:38:31',NULL),
(5,'윈터',2500,'http://localhost:8000/윈터.jpg',2,'2024-05-15 13:41:00',NULL),
(6,'카리나',2700,'http://localhost:8000/카리나.jpg',3,'2024-05-15 13:41:00',NULL),
(7,'민희진',3500,'http://localhost:8000/민희진.jpg',4,'2024-05-15 13:41:00',NULL),
(8,'방시혁',3700,'http://localhost:8000/방시혁.jpg',4,'2024-05-15 13:41:00',NULL),
(9,'이수만',3900,'http://localhost:8000/이수만.jpg',4,'2024-05-15 13:41:00',NULL);

UNLOCK TABLES;

