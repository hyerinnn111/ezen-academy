import React from "react";

import "./Footer.css";

function Footer() {
  return (
    <div >
      <h3>푸터입니다</h3>
    </div>
  );
}

export default Footer;
