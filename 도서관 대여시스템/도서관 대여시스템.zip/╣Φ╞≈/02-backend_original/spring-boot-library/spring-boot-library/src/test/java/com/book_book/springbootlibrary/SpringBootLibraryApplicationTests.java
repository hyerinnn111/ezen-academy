package com.book_book.springbootlibrary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootLibraryApplicationTests {

	@Test
	void contextLoads() {
	}

}
